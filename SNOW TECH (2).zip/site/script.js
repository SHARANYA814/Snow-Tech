document.addEventListener('DOMContentLoaded', () => {
  const body = document.body;
  const dmSwitch = document.getElementById('dm-switch');

  const applyTheme = (theme) => {
    const dark = theme === 'dark';
    body.classList.toggle('dark-theme', dark);
    dmSwitch.classList.toggle('active', dark);
    dmSwitch.setAttribute('aria-pressed', String(dark));
  };
  let savedTheme = 'light';
  try { savedTheme = localStorage.getItem('theme') || 'light'; } catch (e) {}
  applyTheme(savedTheme);

  dmSwitch.addEventListener('click', () => {
    const next = body.classList.contains('dark-theme') ? 'light' : 'dark';
    applyTheme(next);
    try { localStorage.setItem('theme', next); } catch (e) {}
  });

  document.addEventListener('click', (e) => {
    const sparkle = document.createElement('div');
    sparkle.className = 'click-sparkle';
    sparkle.style.left = `${e.clientX}px`;
    sparkle.style.top = `${e.clientY}px`;
    document.body.appendChild(sparkle);
    sparkle.addEventListener('animationend', () => sparkle.remove());
  });

  // ---- Search: real filtering over every course/nav link on the page ----
  const searchIcon = document.querySelector('.search-icon');
  const searchBox = document.querySelector('.search-box');
  const searchContainer = document.querySelector('.search-container');
  const searchResults = document.querySelector('.search-results');
  const indexedLinks = Array.from(document.querySelectorAll('.dropdown a, .course-box .learn-more'))
    .map(a => ({ text: a.textContent.trim(), href: a.getAttribute('href') }))
    .filter(item => item.text && item.href && !item.href.startsWith('#') || item.href);

  const renderResults = (query) => {
    const q = query.trim().toLowerCase();
    if (!q) { searchResults.classList.remove('active'); searchResults.innerHTML=''; return; }
    const matches = indexedLinks.filter(item => item.text.toLowerCase().includes(q)).slice(0, 12);
    searchResults.innerHTML = matches.length
      ? matches.map(m => `<a href="${m.href}">${m.text}</a>`).join('')
      : `<div class="no-results">No courses found for "${query}"</div>`;
    searchResults.classList.add('active');
  };

  searchIcon.addEventListener('click', (event) => {
    event.stopPropagation();
    searchBox.classList.toggle('active');
    if (searchBox.classList.contains('active')) searchBox.focus();
    else searchResults.classList.remove('active');
  });
  searchBox.addEventListener('input', () => renderResults(searchBox.value));
  document.addEventListener('click', (event) => {
    if (!searchContainer.contains(event.target)) {
      searchBox.classList.remove('active');
      searchResults.classList.remove('active');
    }
  });

  // ---- Mobile nav ----
  const hamburgerMenu = document.querySelector('.hamburger-menu');
  const mobileNavOverlay = document.querySelector('.mobile-nav-overlay');
  const closeBtn = document.querySelector('.close-btn');

  const openMobileNav = () => { mobileNavOverlay.classList.add('active'); hamburgerMenu.setAttribute('aria-expanded','true'); };
  const closeMobileNav = () => { mobileNavOverlay.classList.remove('active'); hamburgerMenu.setAttribute('aria-expanded','false'); };

  hamburgerMenu.addEventListener('click', openMobileNav);
  closeBtn.addEventListener('click', closeMobileNav);
  closeBtn.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') closeMobileNav(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeMobileNav(); });

  document.querySelectorAll('.mobile-nav-content > ul > li > a:not(.mobile-dropdown-toggle)').forEach(link => {
    link.addEventListener('click', closeMobileNav);
  });

  document.querySelectorAll('.mobile-dropdown-toggle').forEach(toggle => {
    toggle.addEventListener('click', (event) => {
      event.preventDefault();
      const parentLi = toggle.closest('li');
      const dropdown = parentLi.querySelector('.mobile-dropdown');
      if (!dropdown) return;
      document.querySelectorAll('.mobile-dropdown.active').forEach(open => {
        if (open !== dropdown) { open.classList.remove('active'); open.previousElementSibling.classList.remove('active'); }
      });
      dropdown.classList.toggle('active');
      toggle.classList.toggle('active');
    });
  });

  // ---- Highlight today's business hour row ----
  const daysOfWeek = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  const todayId = daysOfWeek[new Date().getDay()];
  const todayEl = document.getElementById(todayId);
  if (todayEl) { todayEl.style.color = 'var(--gold)'; todayEl.style.fontWeight = 'bold'; }

  // ---- Scroll reveal ----
  const animateOnScroll = document.querySelectorAll(
    '.reason-box, .course-box, .info-left, .info-right, .student-item'
  );
  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) { entry.target.classList.add('is-visible'); obs.unobserve(entry.target); }
    });
  }, { threshold: 0.1 });
  animateOnScroll.forEach(el => observer.observe(el));
});